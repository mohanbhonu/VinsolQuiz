import "./styles.css";
import React, { useState, useEffect } from "react";
import Quiz from "./Quiz";
import Home from "./Home";
import { Grid } from "@material-ui/core";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";

export default function App() {
  const [count, setCount] = useState();
  const [choseOperator, setChooseOperator] = useState();
  const handleClick = (questionCount, opt) => {
    setCount(parseInt(questionCount));
    setChooseOperator(opt);
  };
  return (
    <>
      <Grid container justifyContent="center">
        <h1>Online Quiz context</h1>
      </Grid>
      <Grid container justify="space-around" justifyContent="center">
        <Grid lg={3} md={3} sm={3} item>
          <Router>
            <Routes>
              <Route
                exact
                path="/"
                element={<Home handleClick={handleClick} />}
              />
              <Route
                exact
                path="/quiz"
                element={<Quiz count={count} opt={choseOperator} />}
              />
            </Routes>
          </Router>
        </Grid>
        <Grid lg={3} md={3} sm={3} item>
          <Router>
            <Routes>
              <Route
                exact
                path="/"
                element={<Home handleClick={handleClick} />}
              />
              <Route
                exact
                path="/quiz"
                element={<Quiz count={count} opt={choseOperator} />}
              />
            </Routes>
          </Router>
        </Grid>
      </Grid>
    </>
  );
}
