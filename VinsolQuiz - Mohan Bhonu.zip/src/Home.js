import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./styles.css";
import { Grid, Button } from "@material-ui/core";
import InputLabel from "@material-ui/core/InputLabel";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";

export default function Home(props) {
  const [questionCount, setQuestionCount] = useState(10);
  const [opt, setOpt] = useState();
  const handleQuestionCount = (e) => {
    setQuestionCount(parseInt(e.target.value));
  };
  const handleChangeOperator = (e) => {
    setOpt(e.target.value);
  };
  const buttonClick = () => {
    props.handleClick(questionCount, opt);
  };
  return (
    <Grid container className="startButton">
      <Grid item lg={6} md={12} sm={12} xs={12}>
        <InputLabel htmlFor="operator-native-simple">Select Number</InputLabel>
        <input onChange={handleQuestionCount} style={{ width: "50px" }} />
      </Grid>
      <Grid item md={12} sm={12} xs={12}>
        <FormControl>
          <InputLabel htmlFor="age-native-simple">Operator</InputLabel>
          <Select
            native
            inputProps={{
              name: "operator",
              id: "operator-native-simple"
            }}
            onChange={handleChangeOperator}
          >
            <option style={{ textAlign: "center" }} value="+">
              +
            </option>
            <option style={{ textAlign: "center" }} value={"-"}>
              -
            </option>
            <option style={{ textAlign: "center" }} value={"/"}>
              /
            </option>
            <option style={{ textAlign: "center" }} value={"*"}>
              *
            </option>
          </Select>
        </FormControl>
      </Grid>
      <Grid item lg={6} md={12} sm={12} xs={12}>
        <Button onClick={buttonClick}>
          <Link style={{ color: "green" }} to="/quiz">
            Start Quiz
          </Link>
        </Button>
      </Grid>
    </Grid>
  );
}
