import "./styles.css";
import React, { useState, useEffect } from "react";
export default function Quiz(props) {
  const [completed, setCompleted] = useState(false);
  const [correct, setCorrect] = useState(0);
  const [wrong, setWrong] = useState(0);
  const [index, setIndex] = useState(0);
  const [enterValue, setEnterValue] = useState("");
  const questionsLength = props.count;
  let flag = false;
  const [randomA, setRandomA] = useState(Math.floor(Math.random() * 9 + 1));
  const [randomB, setRandomB] = useState(Math.floor(Math.random() * 9 + 1));
  const [skipped, setSkipped] = useState([]);
  const randomOperators = ["+", "-", "/", "*"];
  const random = Math.floor(Math.random() * randomOperators.length);
  const [operator, setOperator] = useState(
    !props.opt ? randomOperators[random] : props.opt
  );

  const [timer, setTimer] = useState(20);

  let timerId;
  if (timer === 0) {
    clearTimeout(timerId);
  }
  useEffect(() => {
    timerId = setTimeout(() => {
      setTimer(timer - 1);
    }, 1000);
    if (timer === 0) {
      clearTimeout(timerId);
    }
    if (index < questionsLength) {
      if (timer === 0) {
        const random = Math.floor(Math.random() * randomOperators.length);
        !props.opt
          ? setOperator(randomOperators[random])
          : setOperator(props.opt);
        setEnterValue("");
        setIndex(index + 1);
        setSkipped([
          ...skipped,
          `${randomA} ${operator} ${randomB} = ${enterValue}|${flag}`
        ]);
        setTimer(20);
        setRandomA(Math.floor(Math.random() * 9 + 1));
        setRandomB(Math.floor(Math.random() * 9 + 1));
      }
    } else {
      setCompleted(true);
    }
  }, [timer, index, operator, correct, skipped, wrong]);

  const handleChange = (e) => {
    setEnterValue(e.target.value);
  };

  const handleNext = () => {
    if (index === questionsLength) {
      setCompleted(true);
    } else {
      clearTimeout(timerId);
      setRandomA(Math.floor(Math.random() * 9 + 1));
      setRandomB(Math.floor(Math.random() * 9 + 1));
      const random = Math.floor(Math.random() * randomOperators.length);
      !props.opt
        ? setOperator(randomOperators[random])
        : setOperator(props.opt);
      setIndex(index + 1);
      setTimer(20);
      if (operator === "*") {
        if (randomA * randomB === parseInt(enterValue)) {
          setCorrect(correct + 1);
          flag = true;
        } else {
          flag = false;
          setWrong(wrong + 1);
        }
      }
      if (operator === "/") {
        if (randomA / randomB === parseInt(enterValue)) {
          setCorrect(correct + 1);
          flag = true;
        } else {
          flag = false;
          setWrong(wrong + 1);
        }
      }
      if (operator === "-") {
        if (randomA - randomB === parseInt(enterValue)) {
          setCorrect(correct + 1);
          flag = true;
        } else {
          flag = false;
          setWrong(wrong + 1);
        }
      }
      if (operator === "+") {
        if (randomA + randomB === parseInt(enterValue)) {
          setCorrect(correct + 1);
          flag = true;
        } else {
          flag = false;
          setWrong(wrong + 1);
        }
      }

      setSkipped([
        ...skipped,
        `${randomA} ${operator} ${randomB} = ${enterValue}|${flag}`
      ]);

      setEnterValue("");
    }
  };
  const handleReset = () => {
    clearTimeout(timerId);
    setEnterValue("");
    setIndex(0);
    setTimer(20);
    setSkipped([]);
    setCompleted(false);
    setCorrect(0);
  };
  return (
    <div className="App">
      {completed ? (
        <div className="resultContainerStyling">
          <div>
            <p className="paragraph">Correct: {correct}</p>
            <p className="skip-paragraph">Wrong:{wrong} </p>
          </div>
          <div className="skipped">
            {skipped &&
              skipped.map((each, i) => {
                return (
                  <>
                    <h6
                      style={
                        each.includes("true")
                          ? { backgroundColor: "green", color: "#ffffff" }
                          : { backgroundColor: "red", color: "#ffffff" }
                      }
                    >
                      {each && each.split("|")[0]}
                    </h6>
                  </>
                );
              })}
          </div>
        </div>
      ) : (
        <div
          className="mainContainer"
          style={{ height: "27vh", width: "100%" }}
        >
          <div className="question-section-header">
            <div>
              Question {index + 1}/{questionsLength}
            </div>
            <div>0:{timer}</div>
          </div>
          <hr style={{ color: "blue" }} />

          <div>
            <span className="inputField">{randomA}</span>
            <span className="inputField">{operator}</span>
            <span className="inputField">{randomB}</span>
          </div>
          <div>
            <input value={enterValue} onChange={handleChange} />
          </div>
          <div className="submitStyling">
            <button onClick={handleReset}>Reset</button>
            <button onClick={handleNext}>Next</button>
          </div>
        </div>
      )}
    </div>
  );
}
